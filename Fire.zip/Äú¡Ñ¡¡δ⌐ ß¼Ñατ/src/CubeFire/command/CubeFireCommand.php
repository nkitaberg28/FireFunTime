<?php

namespace CubeFire\command;

use pocketmine\command\Command;
use pocketmine\permission\Permission;
use CubeFire\permission\PermissionNames;
use pocketmine\permission\PermissionManager;
use pocketmine\permission\DefaultPermissions;
use pocketmine\command\CommandSender;
use pocketmine\player\Player;
use CubeFire;

class CubeFireCommand extends Command
{
    public function __construct()
    {
        parent::__construct("cubefire", "Получить огненный смерч", aliases: ["cfire"]);

        $candidate = new Permission(PermissionNames::COMMAND_CUBE_FIRE);
        $grantedBy = [PermissionManager::getInstance()->getPermission(DefaultPermissions::ROOT_OPERATOR)];

        DefaultPermissions::registerPermission($candidate, $grantedBy);
        $this->setPermission(PermissionNames::COMMAND_CUBE_FIRE);
    }

    public function execute(CommandSender $sender, string $commandLabel, array $args) : void
    {
        if ($sender instanceof Player)
        {
            if (isset($args[0]))
            {
                $player = $sender->getServer()->getPlayerExact($args[0]);

                if ($player)
                {
                    CubeFire::giveItem($player);

                    return;
                }
            }

            CubeFire::giveItem($sender);

            return;
        }

        $sender->sendMessage("§cИспользуйте только в игре");
    }
}
