<?php

namespace CubeFire\event;

use pocketmine\event\Listener;
use pocketmine\event\player\PlayerItemUseEvent;
use CubeFire;
use pocketmine\player\Player;
use pocketmine\entity\effect\EffectInstance;
use pocketmine\entity\effect\VanillaEffects;
use pocketmine\world\sound\PopSound;
use pocketmine\event\player\PlayerInteractEvent;

class EventHandler implements Listener
{
    public function PlayerItemUseEvent(PlayerItemUseEvent $event) : void
    {
        $item = $event->getItem();

        if ($item->getNamedTag()->getByte(CubeFire::CUBE_FIRE, false))
        {
            $player = $event->getPlayer();
            $world = $player->getWorld();

            foreach ($world->getNearbyEntities($player->getBoundingBox()->expandedCopy(15, 15, 15)) as $players)
            {
                if ($players instanceof Player && $players !== $player)
                {
                    $player->getInventory()->removeItem($item->setCount(1));
                    $players->setOnFire(10);
                    $players->getEffects()->add(new EffectInstance(VanillaEffects::FIRE_RESISTANCE(), 20 * 10));
                    $player->sendPopup("Вы успешно использовали Огненный смерч");
                    $world->addSound($player->getPosition(), new PopSound());

                    return;
                }
            }

            $player->sendTip("§cВ радиусе нет игроков");
        }
    }

    public function PlayerInteractEvent(PlayerInteractEvent $event) : void
    {
        if ($event->getItem()->getNamedTag()->getByte(CubeFire::CUBE_FIRE, false))
        {
            $event->cancel();
        }
    }
}
