<?php

namespace CubeFire\permission;

final class PermissionNames
{
    public const COMMAND_CUBE_FIRE = "command.cube.fire";
}
