<?php

use pocketmine\plugin\PluginBase;
use CubeFire\event\EventHandler;
use CubeFire\command\CubeFireCommand;
use pocketmine\player\Player;
use pocketmine\item\VanillaItems;
use pocketmine\utils\Config;

class CubeFire extends PluginBase
{
    public const CUBE_FIRE = "CubeFire"; //TAG_Byte

    private static Config $config;

    public function onEnable() : void
    {
        $this->saveDefaultConfig();
        self::$config = new Config($this->getDataFolder() . "config.yml", Config::YAML, [
            "item_name" => "§r§6(✦) Огненный смерч",
            "item_lore" => [
                "§7Поджигает всех игроков в радиусе 15 блоков"
            ]
        ]);

        $this->getServer()->getPluginManager()->registerEvents(new EventHandler(), $this);
        $this->getServer()->getCommandMap()->register($this->getName(), new CubeFireCommand());
    }

    public static function giveItem(Player $player) : void
    {
        $item = VanillaItems::FIRE_CHARGE();
        $inventory = $player->getInventory();

        $item->setNamedTag($item->getNamedTag()->setByte(self::CUBE_FIRE, true));
        $item->setCustomName(self::$config->get("item_name", "§r§6(✦) Огненный смерч"));
        $item->setLore(self::$config->get("item_lore", [
            "§7Поджигает всех игроков в радиусе 15 блоков"
        ]));

        if (!$inventory->canAddItem($item))
        {
            $player->sendMessage("§cВаш инвентарь заполнен!");
            return;
        }

        $inventory->addItem($item);
    }
}